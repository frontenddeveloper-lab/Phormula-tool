// app/productwiseperformance/[productname]/[countryName]/[month]/[year]/page.tsx

import ProductwisePerformance from "@/features/productwiseperformance/ProductwisePerformance";

export default function Page() {
  return <ProductwisePerformance />;
}
